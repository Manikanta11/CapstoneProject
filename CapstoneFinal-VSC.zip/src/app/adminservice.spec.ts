import { Adminservice } from './adminservice';

describe('Adminservice', () => {
  it('should create an instance', () => {
    expect(new Adminservice()).toBeTruthy();
  });
});
